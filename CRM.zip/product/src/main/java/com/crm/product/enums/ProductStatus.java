package com.crm.product.enums;

public enum ProductStatus {
    FOR_SALE,
    FOR_RENT,
    IN_STOCK,
    FROM_PARTNER
}

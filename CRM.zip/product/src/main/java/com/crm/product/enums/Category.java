package com.crm.product.enums;

public enum Category {
    RING,
    BRACELET,
    NECKLACE,
    EARRING
}
